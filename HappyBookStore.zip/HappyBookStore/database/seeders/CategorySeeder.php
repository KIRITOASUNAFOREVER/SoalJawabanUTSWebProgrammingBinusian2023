<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\category;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        category::create([
            'id' => '1',
            'category' => "Fiction",
        ]);
        category::create([
            'id' => '2',
            'category' => "Science",
        ]);
        category::create([
            'id' => '3',
            'category' => "Computer",
        ]);
        category::create([
            'id' => '4',
            'category' => "Comedy",
        ]);
    }
}

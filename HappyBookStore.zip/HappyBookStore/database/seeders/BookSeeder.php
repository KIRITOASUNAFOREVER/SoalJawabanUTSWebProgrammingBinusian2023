<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\book;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        book::create([
            'id' => '1',
            'category_id' => "1",
            'title' => "Fiction",
        ]);
        book::create([
            'id' => '2',
            'category_id' => "1",
            'title' => "Fiction 1",
        ]);
        book::create([
            'id' => '3',
            'category_id' => "1",
            'title' => "Fiction 2",
        ]);
        book::create([
            'id' => '4',
            'category_id' => "1",
            'title' => "Fiction 3",
        ]);
        book::create([
            'id' => '5',
            'category_id' => "1",
            'title' => "Fiction 4",
        ]);
        book::create([
            'id' => '6',
            'category_id' => "1",
            'title' => "Fiction 5",
        ]);
        book::create([
            'id' => '7',
            'category_id' => "2",
            'title' => "Science",
        ]);
        book::create([
            'id' => '8',
            'category_id' => "2",
            'title' => "Science 1",
        ]);
        book::create([
            'id' => '9',
            'category_id' => "2",
            'title' => "Science 2",
        ]);
        book::create([
            'id' => '10',
            'category_id' => "2",
            'title' => "Science 3",
        ]);
        book::create([
            'id' => '11',
            'category_id' => "2",
            'title' => "Science 4",
        ]);
        book::create([
            'id' => '12',
            'category_id' => "2",
            'title' => "Science 5",
        ]);
        book::create([
            'id' => '13',
            'category_id' => "3",
            'title' => "Computer",
        ]);
        book::create([
            'id' => '14',
            'category_id' => "3",
            'title' => "Computer 1",
        ]);
        book::create([
            'id' => '15',
            'category_id' => "3",
            'title' => "Computer 2",
        ]);
        book::create([
            'id' => '16',
            'category_id' => "3",
            'title' => "Computer 3",
        ]);
        book::create([
            'id' => '17',
            'category_id' => "3",
            'title' => "Computer 4",
        ]);
        book::create([
            'id' => '18',
            'category_id' => "3",
            'title' => "Computer 5",
        ]);
    }
}


<title>Detail</title>
<?php $__env->startSection('content'); ?>
    <h3 class="bg-warning py-1" style="font-weight: normal;">Book Detail</h3>
    <p>Title: <?php echo e($book_info->title); ?></p>
    <p>Author: <?php echo e($detail_info->author); ?></p>
    <p>Publisher: <?php echo e($detail_info->publisher); ?></p>
    <p>Year: <?php echo e($detail_info->year); ?></p>
    <p>Description:</p>
    <p><?php echo e($detail_info->description); ?></p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\xampp\htdocs\HappyBookStore\resources\views/detail.blade.php ENDPATH**/ ?>

<title><?php echo e($category_info->category); ?> List Book</title>
<?php $__env->startSection('content'); ?>
    <h3 class="bg-warning py-1" style="font-weight: normal;"><?php echo e($category_info->category); ?></h3>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Title</th>
                <th scope="col">Author</th>
            </tr>
        </thead>
        <?php if(count($list_book) > 0): ?>
            <tbody>
                <?php $__currentLoopData = $list_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-href="<?php echo e(route('detail', [$item->detail->id])); ?>" style="cursor: pointer;">
                        <th scope="row" title="Book Detail"><?php echo e($item->title); ?></th>
                        <td title="Book Detail"><?php echo e($item->detail->author); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php else: ?>
            <tbody>
                <tr>
                    <td colspan="2" title="No Data"> <a class="bg-warning" style="display:block;">No data...</a> </td>
                </tr>
            </tbody>
        <?php endif; ?>
    </table>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-end">
            <?php echo e($list_book->links()); ?>

        </ul>
    </nav>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HappyBookStore\resources\views/category.blade.php ENDPATH**/ ?>
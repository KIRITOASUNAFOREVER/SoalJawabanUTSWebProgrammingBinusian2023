
<title>Contact Us</title>
<?php $__env->startSection('content'); ?>
    <h3 class="bg-warning py-1" style="font-weight: normal;">Contact</h3>
    <h2 style="font-weight: normal;">Store address:</h2>
    <p>Jalan Pembangunan Baru Raya,</p>
    <p>Kompleks Pertokoan Emerald Blok III/12</p>
    <p>Bintaro, Tangerang Selatan</p>
    <p>Indonesia</p>
    <h2 style="font-weight: normal;">Open Daily:</h2>
    <p>08.00 - 20.00</p>
    <h2 style="font-weight: normal;">Contact:</h2>
    <p>Phone: 021-08899776655</p>
    <p>Email: happybookstore@happy.com</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\xampp\htdocs\HappyBookStore\resources\views/contact.blade.php ENDPATH**/ ?>
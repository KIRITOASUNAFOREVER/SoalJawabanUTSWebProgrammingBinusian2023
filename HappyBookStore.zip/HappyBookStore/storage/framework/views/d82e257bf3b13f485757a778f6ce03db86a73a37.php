<title>Book List</title>
<?php $__env->startSection('content'); ?>
    <h3 class="bg-warning py-1" style="font-weight: normal;">Book List</h3>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Title</th>
                <th scope="col">Author</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $list_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="table-secondary" data-href="<?php echo e(route('detail', [$item->detail->id])); ?>"
                    style="cursor: pointer;">
                    <th scope="row" title="Book Detail"><?php echo e($item->title); ?></th>
                    <td title="Book Detail"><?php echo e($item->detail->author); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-end">
            <?php echo e($list_book->links()); ?>

        </ul>
    </nav>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kerja\xampp\htdocs\HappyBookStore\resources\views/home.blade.php ENDPATH**/ ?>
@extends('layout')
<title>Book Detail</title>
@section('content')
    <h3 class="bg-warning py-1" style="font-weight: normal;">Book Detail</h3>
    <p>Title: {{ $book_info->title }}</p>
    <p>Author: {{ $detail_info->author }}</p>
    <p>Publisher: {{ $detail_info->publisher }}</p>
    <p>Year: {{ $detail_info->year }}</p>
    <p>Description:</p>
    <p>{{ $detail_info->description }}</p>

@endsection

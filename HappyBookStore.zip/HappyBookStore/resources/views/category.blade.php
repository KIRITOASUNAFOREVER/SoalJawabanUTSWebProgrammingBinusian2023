@extends('layout')
<title>{{ $category_info->category }} List Book</title>
@section('content')
    <h3 class="bg-warning py-1" style="font-weight: normal;">{{ $category_info->category }}</h3>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">Title</th>
                <th scope="col">Author</th>
            </tr>
        </thead>
        @if (count($list_book) > 0)
            <tbody>
                @foreach ($list_book as $key => $item)
                    <tr data-href="{{ route('detail', [$item->detail->id]) }}" style="cursor: pointer;">
                        <th scope="row" title="Book Detail">{{ $item->title }}</th>
                        <td title="Book Detail">{{ $item->detail->author }}</td>
                    </tr>
                @endforeach
            </tbody>
        @else
            <tbody>
                <tr>
                    <td colspan="2" title="No Data"> <a class="bg-warning" style="display:block;">No data...</a> </td>
                </tr>
            </tbody>
        @endif
    </table>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-end">
            {{ $list_book->links() }}
        </ul>
    </nav>



@endsection

@extends('layout')
<title>Home Page</title>
@section('content')
    <h3 class="bg-warning py-1" style="font-weight: normal;">Book List</h3>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Title</th>
                <th scope="col">Author</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($list_book as $key => $item)
                <tr class="table-secondary" data-href="{{ route('detail', [$item->detail->id]) }}"
                    style="cursor: pointer;">
                    <th scope="row" title="Book Detail">{{ $item->title }}</th>
                    <td title="Book Detail">{{ $item->detail->author }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-end">
            {{ $list_book->links() }}
        </ul>
    </nav>



@endsection

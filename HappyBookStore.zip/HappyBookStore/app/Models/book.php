<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class book extends Model
{
    protected $primarykey='id';
    protected $table='books';
    public $timestamps = false;
    protected $fillable=['category_id'.'title'];
    
    public function category()
    {
        return $this->belongsTo(category::class);
    }
    public function detail()
    {
        return $this->hasOne(detail::class);
    }
    use HasFactory;
}

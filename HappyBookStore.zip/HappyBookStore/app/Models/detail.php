<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class detail extends Model
{
    protected $primarykey='id';
    protected $table='details';
    public $timestamps = false;
    protected $fillable=['book_id','author','publisher','year','description'];
    public function book()
    {
        return $this->hasOne(book::class);
    }
    use HasFactory;
}

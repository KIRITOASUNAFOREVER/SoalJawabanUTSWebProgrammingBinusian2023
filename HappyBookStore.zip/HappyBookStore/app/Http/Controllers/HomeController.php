<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\book;
use App\Models\category;
use App\Models\detail;

class HomeController extends Controller
{
    //
    public function index()
    {
        $list_book = book::with('detail')->simplePaginate(5);
        return view('home', ['list_book' => $list_book]);
    }
    public function detail($id)
    {
        $detail_info = detail::find($id);
        $book_info = book::find($detail_info->book_id);
        return view('detail', ['detail_info' => $detail_info, 'book_info' => $book_info]);
    }
}

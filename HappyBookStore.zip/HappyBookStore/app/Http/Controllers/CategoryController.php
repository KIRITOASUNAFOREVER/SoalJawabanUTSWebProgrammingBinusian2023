<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\book;
use App\Models\category;

class CategoryController extends Controller
{
    //
    public function category($category_name)
    {
        $category_info = category::where('category', $category_name)->first();
        $list_book = Book::with('detail')->where('category_id', $category_info->id)->simplePaginate(5);
        return view('category', ['list_book' => $list_book, 'category_info' => $category_info]);
    }
}
